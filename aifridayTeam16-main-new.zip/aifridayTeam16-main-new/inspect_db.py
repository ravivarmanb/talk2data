"""Script to inspect the database structure."""
import sqlite3
import sys

def inspect_database(db_path):
    """Inspect the database structure and print information about tables and columns."""
    print(f"\nInspecting database: {db_path}")
    print("=" * 80)
    
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Get all tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        
        print(f"\nFound {len(tables)} tables:")
        for i, table in enumerate(tables, 1):
            table_name = table['name']
            print(f"\n{i}. Table: {table_name}")
            print("-" * 40)
            
            # Get table info
            try:
                cursor.execute(f"PRAGMA table_info({table_name});")
                columns = cursor.fetchall()
                print("Columns:")
                for col in columns:
                    print(f"  - {col['name']} ({col['type']})")
                
                # Get sample data (first 2 rows)
                cursor.execute(f"SELECT * FROM {table_name} LIMIT 2;")
                rows = cursor.fetchall()
                if rows:
                    print("\nSample data:")
                    for i, row in enumerate(rows, 1):
                        print(f"  Row {i}: {dict(row)}")
                else:
                    print("  No data in table")
                    
            except sqlite3.Error as e:
                print(f"  Error inspecting table: {e}")
                
    except sqlite3.Error as e:
        print(f"Error connecting to database: {e}")
        return
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python inspect_db.py <path_to_database.db>")
        sys.exit(1)
    
    db_path = sys.argv[1]
    inspect_database(db_path)
