"""Main entry point for the Rule2SQL data quality validation tool."""
import os
import sys
import argparse
from typing import List, Dict, Any, Optional

from models.rule import get_active_rules
from services.validation import validate_rules, save_validation_results


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Validate data quality rules against a database.')
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Default paths for both databases
    rules_db = os.path.join(script_dir, 'DataQualityRules.db')
    data_db = os.path.join(script_dir, 'data', 'uk_health_insurance.db')
    
    parser.add_argument('--rules-db', type=str, default=rules_db,
                      help='Path to the rules database (default: DataQualityRules.db)')
    parser.add_argument('--data-db', type=str, default=data_db,
                      help='Path to the data database (default: data/uk_health_insurance.db)')
    parser.add_argument('--output', type=str, default=None,
                      help='Output file for validation results (default: dq_validation_results_<timestamp>.json)')
    parser.add_argument('--rule-id', type=str, default=None,
                      help='Validate a specific rule by ID (default: validate all active rules)')
    parser.add_argument('--debug', action='store_true',
                      help='Enable debug mode with detailed error output')
    
    return parser.parse_args()


def configure_console_encoding():
    """Configure console encoding to handle Unicode characters."""
    import sys
    import codecs
    
    if sys.platform.startswith('win'):
        # On Windows, set the console to use UTF-8 encoding
        sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
        sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')


def main():
    """Main function to run the validation process."""
    # Configure console encoding first
    configure_console_encoding()
    
    args = parse_arguments()
    
    print("=" * 80)
    print("Rule2SQL - Data Quality Validation Tool")
    print("=" * 80)
    
    # Check if databases exist
    if not os.path.exists(args.rules_db):
        print(f"\n❌ Error: Rules database file not found: {os.path.abspath(args.rules_db)}")
        print("Please specify the correct path to your rules database using --rules-db")
        sys.exit(1)
        
    if not os.path.exists(args.data_db):
        print(f"\n❌ Error: Data database file not found: {os.path.abspath(args.data_db)}")
        print("Please specify the correct path to your data database using --data-db")
        sys.exit(1)
    
    try:
        # Get active rules from rules database
        print(f"\n[INFO] Loading active rules from: {os.path.abspath(args.rules_db)}")
        rules = get_active_rules(args.rules_db)
        
        if not rules:
            print("\n[WARNING] No active rules found in the database.")
            sys.exit(0)
        
        # Filter rules if a specific rule ID is provided
        if args.rule_id:
            rules = [r for r in rules if str(r.get('rule_id')) == args.rule_id]
            if not rules:
                print(f"\n[WARNING] No active rule found with ID: {args.rule_id}")
                sys.exit(0)
        
        print(f"\n[INFO] Starting validation of {len(rules)} rule{'s' if len(rules) != 1 else ''}...")
        
        # Validate rules against data database
        print(f"\n[INFO] Validating rules against database: {os.path.abspath(args.data_db)}")
        results = validate_rules(rules, args.data_db)
        
        # Save results
        output_file = save_validation_results(results, args.output)
        
        # Print summary
        passed = sum(1 for r in results if r.get('status') == 'passed')
        failed = sum(1 for r in results if r.get('status') == 'failed')
        errors = sum(1 for r in results if r.get('status') == 'error')
        
        print("\n" + "=" * 80)
        print("Validation Summary:")
        print("-" * 80)
        print(f"[PASSED] {passed}")
        print(f"[FAILED] {failed}")
        print(f"[ERRORS] {errors}")
        print("=" * 80)
        print(f"\nResults saved to: {os.path.abspath(output_file)}")
        
    except Exception as e:
        print(f"\n[ERROR] An error occurred: {str(e)}")
        if '--debug' in sys.argv:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
