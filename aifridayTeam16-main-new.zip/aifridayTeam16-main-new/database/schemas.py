"""Database schema-related functions."""
from typing import Dict, List, Any
import sqlite3


def get_table_schema(conn: sqlite3.Connection, table_name: str) -> Dict[str, str]:
    """Get schema information for a specific table."""
    cursor = conn.cursor()
    
    # Get column information
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = {}
    for row in cursor.fetchall():
        columns[row[1]] = row[2]  # column_name: data_type
    
    # Get foreign key information
    cursor.execute(f"PRAGMA foreign_key_list({table_name})")
    foreign_keys = {}
    for row in cursor.fetchall():
        foreign_keys[row[3]] = {  # column_name
            'table': row[2],      # referenced table
            'to': row[4]          # referenced column
        }
    
    # Get index information
    cursor.execute(f"PRAGMA index_list({table_name})")
    indexes = {}
    for row in cursor.fetchall():
        index_name = row[1]
        cursor.execute(f"PRAGMA index_info({index_name})")
        index_columns = [r[2] for r in cursor.fetchall()]  # column names in index
        indexes[index_name] = index_columns
    
    return {
        'columns': columns,
        'foreign_keys': foreign_keys,
        'indexes': indexes
    }


def get_all_table_schemas(conn: sqlite3.Connection) -> Dict[str, Dict[str, Any]]:
    """Get schemas for all tables in the database."""
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [row[0] for row in cursor.fetchall()]
    
    schemas = {}
    for table in tables:
        try:
            schemas[table] = get_table_schema(conn, table)
        except sqlite3.Error as e:
            print(f"Error getting schema for table {table}: {str(e)}")
    
    return schemas


def get_table_names(conn: sqlite3.Connection) -> List[str]:
    """Get all table names in the database."""
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    return [row[0] for row in cursor.fetchall()]
