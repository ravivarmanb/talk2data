"""Database connection and basic operations."""
import sqlite3
from typing import Optional, Dict, Any, List


def get_connection(db_path: str) -> sqlite3.Connection:
    """Create and return a database connection with row factory set."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def close_connection(conn: sqlite3.Connection) -> None:
    """Close the database connection."""
    if conn:
        conn.close()


def execute_query(conn: sqlite3.Connection, query: str, params: tuple = None) -> List[Dict[str, Any]]:
    """Execute a query and return results as a list of dictionaries."""
    cursor = conn.cursor()
    cursor.execute(query, params or ())
    return [dict(row) for row in cursor.fetchall()]
