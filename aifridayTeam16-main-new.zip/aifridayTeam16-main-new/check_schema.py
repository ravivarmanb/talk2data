import sqlite3

def get_schema():
    # Connect to the SQLite database
    conn = sqlite3.connect('data/uk_health_insurance.db')
    cursor = conn.cursor()
    
    # Get all table names
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    
    print("\nDatabase Schema:")
    print("-" * 50)
    
    # Get schema for each table
    for table in tables:
        table_name = table[0]
        print(f"\nTable: {table_name}")
        print("-" * 50)
        
        # Get column info
        cursor.execute(f"PRAGMA table_info({table_name});")
        columns = cursor.fetchall()
        
        # Print column details
        for col in columns:
            print(f"{col[1]} ({col[2]}) - {'PRIMARY KEY' if col[5] == 1 else ''}")
    
    # Close the connection
    conn.close()

if __name__ == "__main__":
    get_schema()
