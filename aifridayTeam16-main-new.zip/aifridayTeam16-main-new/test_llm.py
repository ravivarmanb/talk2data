import os
import json
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
import httpx

load_dotenv()

try:
    client = httpx.Client(verify=False)
    llm = ChatOpenAI(
        base_url='https://genailab.tcs.in',
        model='azure_ai/genailab-maas-DeepSeek-V3-0324',
        api_key=os.getenv('OPENAI_API_KEY'),
        http_client=client
    )
    
    # Test the exact prompt
    all_tables = ['customers', 'policies', 'claims']
    prompt = f"""Analyze the following data quality rule and database schema to identify the relevant tables and columns.

    Rule Details:
    - Description: validate that mandatory demographic attributes (first_name, last_name, dob, gender, nhs_number) are fully populated
    - Domain: member
    - Rule Type: Completeness
    
    Available Tables: {', '.join(all_tables)}
    
    For each table that might be relevant to this rule, list the columns that should be validated.
    Return a JSON object with table names as keys and lists of column names as values.
    Only include tables and columns that are directly relevant to the rule.
    
    Example format:
    {{
        "table1": ["column1", "column2"],
        "table2": ["column3", "column4"]
    }}
    
    Your response should be a valid JSON object only, with no additional text."""
    
    response = llm.invoke(prompt)
    print('Raw LLM Response:')
    print(repr(response.content))
    print('\nParsed Response:')
    try:
        # Clean up the response to extract just the JSON
        content = response.content.strip()
        
        # Remove code block markers if present
        if content.startswith('```json'):
            content = content[7:]
        if content.startswith('```'):
            content = content[3:]
        if content.endswith('```'):
            content = content[:-3]
        content = content.strip()
        
        result = json.loads(content)
        print('Success:', result)
    except Exception as e:
        print('JSON Parse Error:', str(e))
    
except Exception as e:
    print('Error:', str(e))
