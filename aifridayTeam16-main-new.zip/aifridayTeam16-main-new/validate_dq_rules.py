import json
import re
import sqlite3
import os
import time
from datetime import datetime
from typing import List, Dict, Any, Optional, Set
import httpx
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize HTTP client with SSL verification disabled
client = httpx.Client(verify=False)

# Initialize the LLM with the provided configuration
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key=os.getenv("OPENAI_API_KEY"),
    http_client=client
)

def get_active_rules(db_path: str) -> List[Dict[str, Any]]:
    """Fetch active rules with status 1 and end_date >= current_date."""
    current_date = datetime.now().strftime("%Y-%m-%d")
    print(f"Current date: {current_date}")
    print(f"Connecting to database: {os.path.abspath(db_path)}")
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # First, let's check what tables exist in the database
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    print(f"Tables in database: {[t[0] for t in tables]}")
    
    # Then check if dq_rules exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='dq_rules';")
    if not cursor.fetchone():
        print("⚠️ Error: 'dq_rules' table not found in the database")
        return []
    
    # Now try to get the rules
    print("Fetching active rules...")
    cursor.execute("""
        SELECT * FROM dq_rules dr
        join dq_rule_domains drd on drd.rule_id = dr.rule_id
        WHERE status_id = 1 and is_live = 'Y'
        AND (end_date IS NULL OR end_date >= ?)
    """, (current_date,))
    
    rules = [dict(row) for row in cursor.fetchall()]
    print(f"Found {len(rules)} active rules")
    
    # Print the first rule as an example
    if rules:
        print("\nExample rule:")
        for key, value in rules[0].items():
            print(f"  {key}: {value}")
    
    conn.close()
    return rules

def get_table_schema(conn, table_name: str) -> Optional[str]:
    """Get schema information for a specific table."""
    if not table_name:
        return None
        
    try:
        cursor = conn.cursor()
        
        # Check if table exists
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND LOWER(name)=LOWER(?)",
            (table_name,)
        )
        if not cursor.fetchone():
            return None
        
        # Get column information
        cursor.execute(f"PRAGMA table_info({table_name})")
        columns = cursor.fetchall()
        
        # Get foreign key information
        cursor.execute(f"PRAGMA foreign_key_list({table_name})")
        fks = cursor.fetchall()
        
        # Format schema information
        schema = f"Table: {table_name}\nColumns:\n"
        for col in columns:
            schema += f"- {col[1]} ({col[2]})"
            if col[5]:  # Primary key
                schema += " PRIMARY KEY"
            if not col[3]:  # Not null
                schema += " NOT NULL"
            if col[4] is not None:  # Default value
                schema += f" DEFAULT {col[4]}"
            schema += "\n"
        
        if fks:
            schema += "\nForeign Keys:\n"
            for fk in fks:
                schema += f"- {fk[3]} references {fk[2]}({fk[4]})\n"
        
        return schema
    except Exception as e:
        print(f"Error getting schema for table '{table_name}': {str(e)}")
        return None

def get_all_table_schemas(conn) -> Dict[str, str]:
    """Get schemas for all tables in the database."""
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [row[0] for row in cursor.fetchall()]
    
    schemas = {}
    for table in tables:
        schema = get_table_schema(conn, table)
        if schema:
            schemas[table] = schema
    
    return schemas

def identify_tables_and_columns_llm(rule: Dict[str, Any], all_schemas: Dict[str, str]) -> Dict[str, List[str]]:
    """
    Use LLM to identify relevant tables and columns based on rule info and table descriptions.
    
    Args:
        rule: Dictionary containing rule details including 'description' and other metadata
        all_schemas: Dictionary mapping table names to their schema descriptions
        
    Returns:
        Dictionary mapping table names to their relevant columns
    """
    if not rule.get('description'):
        return {}
    
    # Prepare rule details for LLM
    rule_details = {
        'rule_id': rule.get('rule_id', ''),
        'rule_name': rule.get('rule_name', ''),
        'description': rule.get('description', ''),
        'rule_type': rule.get('rule_type', ''),
        'severity': rule.get('severity', ''),
        'domain_name': rule.get('domain_name', ''),
        'target_table': rule.get('target_table', ''),
        'target_columns': rule.get('target_columns', '')
    }
    
    # Prepare schema information with table descriptions
    schema_info = []
    for table_name, schema_desc in all_schemas.items():
        schema_info.append({
            'table_name': table_name,
            'schema_description': schema_desc
        })
    
    prompt = f"""You are a data quality expert. Analyze the following data quality rule and database table schemas to identify which tables and columns should be validated.

Rule Information:
{json.dumps(rule_details, indent=2)}

Available Database Tables and Their Schemas:
{json.dumps(schema_info, indent=2)}

Based on the rule description, domain, rule type, and the table schemas provided, identify which tables and columns are relevant for validating this rule.

Important considerations:
1. The domain '{rule_details.get('domain_name', '')}' may indicate the primary table or area of focus
2. Analyze the rule description to understand what data elements need to be validated
3. Match the rule requirements with the appropriate tables and columns from the schema
4. Consider relationships between tables if the rule involves multiple entities
5. Identify all columns that are mentioned or implied in the rule description

Return your response as a JSON object with the following format:
{{
    "tables": [
        {{
            "name": "table_name",
            "columns": ["column1", "column2", ...],
            "relevance": "high|medium|low",
            "reasoning": "brief explanation of why this table is relevant"
        }},
        ...
    ]
}}

Include only the JSON response, no additional text or explanation. Use actual table and column names from the schemas provided.
"""
    
    try:
        response = llm.invoke(prompt)
        content = response.content.strip()
        
        # Try to extract JSON from the response (in case LLM adds extra text)
        json_match = re.search(r'\{.*\}', content, re.DOTALL)
        if json_match:
            content = json_match.group(0)
        
        result = json.loads(content)
        
        # Convert to the expected format
        table_columns = {}
        for table_info in result.get('tables', []):
            table_name = table_info.get('name', '').strip()
            columns = table_info.get('columns', [])
            if table_name and columns:
                # Ensure table name exists in schemas (case-insensitive match)
                actual_table_name = None
                for schema_table in all_schemas.keys():
                    if schema_table.lower() == table_name.lower():
                        actual_table_name = schema_table
                        break
                
                if actual_table_name:
                    table_columns[actual_table_name] = [col.strip() for col in columns if col]
        
        return table_columns
        
    except Exception as e:
        print(f"Error using LLM to identify tables and columns: {str(e)}")
        print(f"LLM response was: {response.content if 'response' in locals() else 'N/A'}")
        return {}

def generate_validation_sqls_llm(rule: Dict[str, Any], table_columns: Dict[str, List[str]], all_schemas: Dict[str, str]) -> List[Dict[str, Any]]:
    """
    Use LLM to generate single or multiple SQL queries to validate the rule.
    
    Args:
        rule: Dictionary containing rule details
        table_columns: Dictionary mapping table names to their relevant columns
        all_schemas: Dictionary mapping table names to their schema descriptions
        
    Returns:
        List of dictionaries, each containing 'table_name', 'sql_query', and 'columns'
    """
    if not table_columns:
        return []
    
    sql_queries = []
    
    # Prepare rule details
    rule_details = rule.copy()
    for key in list(rule_details.keys()):
        if isinstance(rule_details[key], (bytes, bytearray)):
            rule_details[key] = "<binary data>"
    
    # Generate SQL for each identified table
    for table_name, columns in table_columns.items():
        if table_name not in all_schemas:
            continue
        
        table_schema = all_schemas[table_name]
        
        prompt = f"""You are a SQL expert specializing in data quality validation. Generate a SQL query to validate the following data quality rule against a specific table.

Rule Details:
{json.dumps(rule_details, indent=2, default=str)}

Target Table: {table_name}
Target Columns: {', '.join(columns) if columns else 'All relevant columns'}

Table Schema:
{table_schema}

Generate a SQL query that identifies records in the '{table_name}' table that violate this rule. The query should:
1. Target the '{table_name}' table
2. Focus on the columns: {', '.join(columns) if columns else 'all relevant columns based on the rule'}
3. Return the primary key(s) and relevant columns of the violating records
4. Use SQLite syntax (this is a SQLite database)
5. Handle NULL values correctly
6. Format dates and numbers appropriately
7. Be optimized for performance
8. Return ONLY records that violate the rule (not all records)

Important SQLite considerations:
- Use SQLite date functions: date('now'), strftime('%Y-%m-%d', column)
- For pattern matching, use LIKE or GLOB (not REGEXP)
- Use CAST() for type conversions
- Use LENGTH() for string length checks

Return ONLY the SQL query with no additional text, explanations, or code block markers. The SQL should be ready to execute directly.
"""
        
        try:
            response = llm.invoke(prompt)
            sql = response.content.strip()
            
            # Remove code block markers if present
            sql = re.sub(r'^```(?:sql)?\s*|\s*```$', '', sql, flags=re.IGNORECASE | re.MULTILINE)
            sql = sql.strip()
            
            # Remove any leading/trailing quotes or special characters
            sql = re.sub(r'^["\']|["\']$', '', sql)
            
            if sql:
                sql_queries.append({
                    'table_name': table_name,
                    'sql_query': sql,
                    'columns': columns
                })
        except Exception as e:
            print(f"Error generating SQL for table {table_name}, rule {rule.get('rule_id')}: {str(e)}")
            continue
    
    return sql_queries

def execute_validation(conn, sql_query: str) -> tuple[List[Dict[str, Any]], Optional[str]]:
    """
    Execute a validation query and return results.
    
    Returns:
        Tuple of (results list, error message if any)
    """
    if not sql_query:
        return [], None
        
    try:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute(sql_query)
        
        if cursor.description:
            columns = [desc[0] for desc in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            return results, None
        return [], None
    except Exception as e:
        error_msg = str(e)
        print(f"Error executing query: {error_msg}")
        return [], error_msg

def generate_execution_result_llm(rule: Dict[str, Any], sql_queries: List[Dict[str, Any]], 
                                   execution_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Use LLM to generate comprehensive execution result in JSON format.
    
    Args:
        rule: Dictionary containing rule details
        sql_queries: List of SQL queries that were executed
        execution_results: List of execution results (each containing table_name, violations, error, etc.)
        
    Returns:
        Dictionary with comprehensive execution result
    """
    # Prepare rule details
    rule_details = rule.copy()
    for key in list(rule_details.keys()):
        if isinstance(rule_details[key], (bytes, bytearray)):
            rule_details[key] = "<binary data>"
    
    # Prepare execution summary
    execution_summary = []
    total_validated = 0
    total_violations = 0
    
    for result in execution_results:
        exec_info = {
            'table_name': result.get('table_name', ''),
            'sql_query': result.get('sql_query', ''),
            'records_validated': result.get('records_validated', 0),
            'violation_count': result.get('violation_count', 0),
            'violations': result.get('violations', [])[:10],  # Limit to first 10 for LLM processing
            'error': result.get('error'),
            'execution_time_seconds': result.get('execution_time_seconds', 0)
        }
        execution_summary.append(exec_info)
        total_validated += exec_info['records_validated']
        total_violations += exec_info['violation_count']
    
    prompt = f"""You are a data quality analyst. Generate a comprehensive execution result in JSON format for a data quality rule validation.

Rule Details:
{json.dumps(rule_details, indent=2, default=str)}

Execution Summary:
{json.dumps(execution_summary, indent=2, default=str)}

Total Records Validated: {total_validated}
Total Violations Found: {total_violations}

Based on the rule details and execution results, generate a comprehensive JSON result with the following structure:
{{
    "rule_id": "rule identifier",
    "rule_name": "rule name",
    "domain": "domain name",
    "rule_type": "rule type",
    "severity": "severity level",
    "sql_queries": [
        {{
            "table_name": "table name",
            "sql_query": "the SQL query executed",
            "columns_validated": ["column1", "column2"]
        }}
    ],
    "execution_summary": {{
        "total_records_validated": number,
        "total_violations": number,
        "tables_validated": ["table1", "table2"],
        "execution_time_seconds": total_time
    }},
    "violations_by_table": [
        {{
            "table_name": "table name",
            "column_name": "column name (if applicable)",
            "violation_count": number,
            "sample_violations": [{{"key": "value", ...}}, ...]
        }}
    ],
    "status": "passed|failed|error",
    "timestamp": "ISO timestamp"
}}

Important:
- Include all SQL queries that were executed
- For each table, identify which columns had violations
- Include sample violation records (limit to 5 per table)
- Calculate total records validated (sum across all queries)
- Determine overall status: "passed" if no violations, "failed" if violations found, "error" if errors occurred
- Include violated table and column details

Return ONLY the JSON object, no additional text or explanation.
"""
    
    try:
        response = llm.invoke(prompt)
        content = response.content.strip()
        
        # Try to extract JSON from the response
        json_match = re.search(r'\{.*\}', content, re.DOTALL)
        if json_match:
            content = json_match.group(0)
        
        result = json.loads(content)
        
        # Add any missing fields
        result['rule_id'] = rule.get('rule_id', result.get('rule_id', ''))
        result['rule_name'] = rule.get('rule_name', result.get('rule_name', ''))
        result['domain'] = rule.get('domain_name', result.get('domain', ''))
        result['timestamp'] = datetime.now().isoformat()
        
        return result
        
    except Exception as e:
        print(f"Error generating execution result with LLM: {str(e)}")
        # Fallback to manual result generation
        return _generate_fallback_result(rule, sql_queries, execution_results)

def _generate_fallback_result(rule: Dict[str, Any], sql_queries: List[Dict[str, Any]], 
                              execution_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generate a fallback result if LLM fails."""
    total_validated = sum(r.get('records_validated', 0) for r in execution_results)
    total_violations = sum(r.get('violation_count', 0) for r in execution_results)
    has_errors = any(r.get('error') for r in execution_results)
    
    violations_by_table = []
    for result in execution_results:
        if result.get('violation_count', 0) > 0:
            violations_by_table.append({
                'table_name': result.get('table_name', ''),
                'violation_count': result.get('violation_count', 0),
                'sample_violations': result.get('violations', [])[:5]
            })
    
    status = 'error' if has_errors else ('passed' if total_violations == 0 else 'failed')
    
    return {
        'rule_id': rule.get('rule_id', ''),
        'rule_name': rule.get('rule_name', ''),
        'domain': rule.get('domain_name', ''),
        'rule_type': rule.get('rule_type', ''),
        'severity': rule.get('severity', ''),
        'sql_queries': [
            {
                'table_name': sq.get('table_name', ''),
                'sql_query': sq.get('sql_query', ''),
                'columns_validated': sq.get('columns', [])
            }
            for sq in sql_queries
        ],
        'execution_summary': {
            'total_records_validated': total_validated,
            'total_violations': total_violations,
            'tables_validated': [r.get('table_name', '') for r in execution_results],
            'execution_time_seconds': sum(r.get('execution_time_seconds', 0) for r in execution_results)
        },
        'violations_by_table': violations_by_table,
        'status': status,
        'timestamp': datetime.now().isoformat()
    }

def get_total_record_count(conn, table_name: str) -> int:
    """Get total record count for a table."""
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        return cursor.fetchone()[0]
    except:
        return 0

def save_results(results: List[Dict[str, Any]], output_file: str = None) -> str:
    """Save validation results to a JSON file."""
    if not output_file:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"dq_validation_results_{timestamp}.json"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "results": results
        }, f, indent=2, ensure_ascii=False)
    
    return os.path.abspath(output_file)

def main():
    # Set console encoding to UTF-8 for Windows
    import sys
    import io
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    
    # Configuration
    rules_db_path = "./DataQualityRules.db"
    target_db_path = "./uk_health_insurance.db"  # Updated path
    output_file = None  # Will be auto-generated with timestamp
    
    if not os.path.exists(rules_db_path):
        print(f"Error: Rules database not found at {os.path.abspath(rules_db_path)}")
        return
    
    if not os.path.exists(target_db_path):
        print(f"Error: Target database not found at {os.path.abspath(target_db_path)}")
        return
    
    try:
        # Connect to target database
        target_conn = sqlite3.connect(target_db_path)
        
        # Get all table schemas up front
        print("Loading database schemas...")
        all_schemas = get_all_table_schemas(target_conn)
        print(f"Found {len(all_schemas)} tables in the database.")
        
        # Get active rules
        print("\nFetching active rules...")
        rules = get_active_rules(rules_db_path)
        print(f"Found {len(rules)} active rules to validate.")
        
        if not rules:
            print("No active rules found.")
            return
        
        results = []
        
        # Process each rule
        for rule_idx, rule in enumerate(rules, 1):
            print(f"\n{'='*80}")
            print(f"Processing rule {rule_idx}/{len(rules)}: {rule.get('rule_name')} (ID: {rule.get('rule_id')})")
            print(f"{'='*80}")
            
            rule_id = rule.get('rule_id', 'unknown')
            
            try:
                # Step 1: Use LLM to identify tables and columns
                print("\n[Step 1] Identifying relevant tables and columns using LLM...")
                table_columns = identify_tables_and_columns_llm(rule, all_schemas)
                
                if not table_columns:
                    print("  ⚠️ No tables identified for this rule")
                    results.append({
                        'rule_id': rule_id,
                        'rule_name': rule.get('rule_name', ''),
                        'status': 'error',
                        'error': 'No tables identified for validation',
                        'timestamp': datetime.now().isoformat()
                    })
                    continue
                
                print(f"  ✓ Identified {len(table_columns)} table(s): {', '.join(table_columns.keys())}")
                for table, cols in table_columns.items():
                    print(f"    - {table}: {len(cols)} column(s)")
                
                # Step 2: Generate SQL queries using LLM
                print("\n[Step 2] Generating SQL queries using LLM...")
                sql_queries = generate_validation_sqls_llm(rule, table_columns, all_schemas)
                
                if not sql_queries:
                    print("  ⚠️ No SQL queries generated")
                    results.append({
                        'rule_id': rule_id,
                        'rule_name': rule.get('rule_name', ''),
                        'status': 'error',
                        'error': 'No SQL queries generated',
                        'timestamp': datetime.now().isoformat()
                    })
                    continue
                
                print(f"  ✓ Generated {len(sql_queries)} SQL query/queries")
                
                # Step 3: Execute SQL queries
                print("\n[Step 3] Executing SQL queries...")
                execution_results = []
                
                for sq in sql_queries:
                    table_name = sq['table_name']
                    sql_query = sq['sql_query']
                    
                    print(f"  Executing query for table: {table_name}")
                    start_time = time.time()
                    
                    violations, error = execute_validation(target_conn, sql_query)
                    execution_time = time.time() - start_time
                    
                    # Get total record count for the table
                    total_records = get_total_record_count(target_conn, table_name)
                    
                    execution_results.append({
                        'table_name': table_name,
                        'sql_query': sql_query,
                        'columns': sq.get('columns', []),
                        'violations': violations,
                        'violation_count': len(violations),
                        'records_validated': total_records,
                        'error': error,
                        'execution_time_seconds': execution_time
                    })
                    
                    if error:
                        print(f"    ❌ Error: {error}")
                    else:
                        print(f"    ✓ Found {len(violations)} violation(s) in {total_records} record(s)")
                
                # Step 4: Generate comprehensive execution result using LLM
                print("\n[Step 4] Generating comprehensive execution result using LLM...")
                final_result = generate_execution_result_llm(rule, sql_queries, execution_results)
                
                print(f"  ✓ Result generated: Status = {final_result.get('status', 'unknown')}")
                print(f"    Total violations: {final_result.get('execution_summary', {}).get('total_violations', 0)}")
                
                results.append(final_result)
                
            except Exception as e:
                print(f"  ❌ Error processing rule: {str(e)}")
                import traceback
                traceback.print_exc()
                results.append({
                    'rule_id': rule_id,
                    'rule_name': rule.get('rule_name', ''),
                    'status': 'error',
                    'error': str(e),
                    'timestamp': datetime.now().isoformat()
                })
        
        # Save results
        if results:
            output_path = save_results(results, output_file)
            print(f"\n{'='*80}")
            print("Validation Complete!")
            print(f"{'='*80}")
            print(f"\nResults saved to: {output_path}")
            
            # Print summary
            passed = sum(1 for r in results if r.get('status') == 'passed')
            failed = sum(1 for r in results if r.get('status') == 'failed')
            errors = sum(1 for r in results if r.get('status') == 'error')
            total_violations = sum(r.get('execution_summary', {}).get('total_violations', 0) for r in results)
            
            print("\nValidation Summary:")
            print(f"- Total rules processed: {len(results)}")
            print(f"- Rules passed: {passed}")
            print(f"- Rules failed: {failed}")
            print(f"- Rules with errors: {errors}")
            print(f"- Total violations found: {total_violations}")
        
    except Exception as e:
        print(f"Error during validation: {str(e)}")
        import traceback
        traceback.print_exc()
        raise
    finally:
        if 'target_conn' in locals():
            target_conn.close()

if __name__ == "__main__":
    main()
