"""
Data Quality Rule Validator
This script:
1. Fetches active rules from dq_rules (is_live='Y' and end_date IS NULL or > sysdate)
2. Uses LLM to identify target tables and columns from uk_health_insurance database
3. Generates SQL queries (possibly multiple) for each rule/domain/table combination
4. Executes SQL queries against the database
5. Uses LLM to validate results against the rule
6. Reports violations in JSON format
"""

import json
import re
import sqlite3
import os
import time
from datetime import datetime
from typing import List, Dict, Any, Optional
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize the LLM - Gemini Flash 2.5
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    google_api_key=os.getenv("GEMINI_API_KEY"),
    temperature=0.1
)

# ============================================================================
# TASK 1: Fetch active rules from dq_rules
# ============================================================================

def fetch_active_rules(rules_db_path: str) -> List[Dict[str, Any]]:
    """
    Fetch rules where is_live='Y' and (end_date IS NULL OR end_date > sysdate).
    
    Args:
        rules_db_path: Path to the DataQualityRules database
        
    Returns:
        List of rule dictionaries
    """
    current_date = datetime.now().strftime("%Y-%m-%d")
    print(f"\n[Task 1] Fetching active rules...")
    print(f"Current date: {current_date}")
    print(f"Rules DB: {os.path.abspath(rules_db_path)}")
    
    conn = sqlite3.connect(rules_db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # Check if dq_rules table exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='dq_rules';")
    if not cursor.fetchone():
        print("❌ Error: 'dq_rules' table not found")
        conn.close()
        return []
    
    # First, check what columns exist in dq_rules to find the domain column
    cursor.execute("PRAGMA table_info(dq_rules)")
    columns_info = cursor.fetchall()
    column_names = [col[1] for col in columns_info]
    
    # Try to find domain column - rule_domains is the correct column name
    domain_column = None
    for col_name in ['rule_domains', 'domain', 'domain_name', 'domains']:
        if col_name in column_names:
            domain_column = col_name
            break
    
    if not domain_column:
        print("  ⚠️ Warning: No domain column found in dq_rules table (checked: rule_domains, domain, domain_name, domains)")
        domain_column = 'rule_domains'  # Default fallback
    
    # Fetch active rules - domain is stored as comma-separated in dq_rules
    query = f"""
        SELECT 
            *
        FROM dq_rules
        WHERE is_live = 'Y'
        AND (end_date IS NULL OR end_date > ?)
        ORDER BY rule_id
    """
    
    cursor.execute(query, (current_date,))
    rules = []
    
    for row in cursor.fetchall():
        rule_dict = dict(row)
        
        # Extract domain from the rule (comma-separated)
        domain_value = rule_dict.get(domain_column, '') or ''
        if domain_value:
            # Split comma-separated domains and clean them
            domains = [d.strip() for d in str(domain_value).split(',') if d.strip()]
            rule_dict['domain_name'] = ', '.join(domains)  # Keep as comma-separated string
            rule_dict['domains'] = domains  # Also store as list for convenience
        else:
            rule_dict['domain_name'] = ''
            rule_dict['domains'] = []
        
        rules.append(rule_dict)
    
    print(f"✓ Found {len(rules)} active rule(s)")
    if rules:
        example_rule = rules[0]
        domains_str = example_rule.get('domain_name', 'N/A')
        print(f"  Example: {example_rule.get('rule_id')} - {example_rule.get('rule_name', 'N/A')} (Domains: {domains_str})")
    
    conn.close()
    return rules

# ============================================================================
# TASK 2: Use LLM to identify target tables and columns
# ============================================================================

def get_table_schema_info(conn: sqlite3.Connection, table_name: str) -> Dict[str, Any]:
    """Get detailed schema information for a table."""
    cursor = conn.cursor()
    
    # Get column information
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = []
    for row in cursor.fetchall():
        columns.append({
            'name': row[1],
            'type': row[2],
            'not_null': not row[3],
            'default_value': row[4],
            'primary_key': bool(row[5])
        })
    
    # Get foreign key information
    cursor.execute(f"PRAGMA foreign_key_list({table_name})")
    foreign_keys = []
    for row in cursor.fetchall():
        foreign_keys.append({
            'from_column': row[3],
            'to_table': row[2],
            'to_column': row[4]
        })
    
    # Get sample data count
    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
    record_count = cursor.fetchone()[0]
    
    return {
        'table_name': table_name,
        'columns': columns,
        'foreign_keys': foreign_keys,
        'record_count': record_count
    }

def get_all_table_schemas(conn: sqlite3.Connection) -> Dict[str, Dict[str, Any]]:
    """Get schemas for all tables in the database."""
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    tables = [row[0] for row in cursor.fetchall()]
    
    schemas = {}
    for table in tables:
        try:
            schemas[table] = get_table_schema_info(conn, table)
        except Exception as e:
            print(f"  ⚠️ Error getting schema for {table}: {str(e)}")
    
    return schemas

def identify_tables_columns_llm(rule: Dict[str, Any], all_schemas: Dict[str, Dict[str, Any]]) -> Dict[str, List[str]]:
    """
    Use LLM to identify target tables and columns for validation.
    
    Args:
        rule: Rule dictionary
        all_schemas: Dictionary of all table schemas from target database
        
    Returns:
        Dictionary mapping table names to list of column names
    """
    print(f"\n[Task 2] Identifying tables and columns using LLM for rule {rule.get('rule_id')}...", flush=True)
    
    # Prepare rule information
    rule_info = {
        'rule_id': rule.get('rule_id', ''),
        'rule_name': rule.get('rule_name', ''),
        'description': rule.get('description', ''),
        'rule_type': rule.get('rule_type', ''),
        'severity': rule.get('severity', ''),
        'domain_name': rule.get('domain_name', ''),
        'target_table': rule.get('target_table', ''),
        'target_columns': rule.get('target_columns', '')
    }
    
    # Prepare schema information in a readable format
    schema_summary = []
    for table_name, schema_info in all_schemas.items():
        columns_str = ', '.join([col['name'] for col in schema_info['columns']])
        schema_summary.append({
            'table_name': table_name,
            'columns': columns_str,
            'column_details': schema_info['columns'],
            'record_count': schema_info['record_count'],
            'foreign_keys': schema_info['foreign_keys']
        })
    
    prompt = f"""You are a data quality expert. Analyze the following data quality rule and identify which tables and columns from the target database should be validated.

Rule Information:
{json.dumps(rule_info, indent=2)}

Available Tables in Target Database (uk_health_insurance):
{json.dumps(schema_summary, indent=2)}

Based on the rule description, domain, and rule type, identify:
1. Which tables are relevant for this rule
2. Which specific columns in each table need to be validated

Consider:
- The domain(s) '{rule_info.get('domain_name', '')}' (may be comma-separated) may indicate the primary focus area(s)
- The rule description explains what needs to be validated
- Match rule requirements with appropriate tables and columns
- Consider table relationships if the rule involves multiple entities
- If multiple domains are specified, consider all of them when identifying relevant tables

Return ONLY a JSON object in this format:
{{
    "tables": [
        {{
            "table_name": "exact_table_name_from_schema",
            "columns": ["column1", "column2", ...],
            "reasoning": "why this table/columns are relevant"
        }}
    ]
}}

Use exact table and column names from the schemas provided. Return only JSON, no additional text.
"""
    
    try:
        response = llm.invoke(prompt)
        content = response.content.strip()
        
        # Extract JSON from response
        json_match = re.search(r'\{.*\}', content, re.DOTALL)
        if json_match:
            content = json_match.group(0)
        
        result = json.loads(content)
        
        # Convert to expected format
        table_columns = {}
        for table_info in result.get('tables', []):
            table_name = table_info.get('table_name', '').strip()
            columns = table_info.get('columns', [])
            
            # Match table name case-insensitively
            actual_table_name = None
            for schema_table in all_schemas.keys():
                if schema_table.lower() == table_name.lower():
                    actual_table_name = schema_table
                    break
            
            if actual_table_name and columns:
                table_columns[actual_table_name] = [col.strip() for col in columns if col.strip()]
                print(f"  ✓ Identified: {actual_table_name} ({len(table_columns[actual_table_name])} columns)")
        
        if not table_columns:
            print("  ⚠️ No tables identified")
        
        return table_columns
        
    except Exception as e:
        print(f"  ❌ Error: {str(e)}")
        return {}

# ============================================================================
# TASK 3 & 4: Generate SQL queries (possibly multiple) for each rule/domain/table
# ============================================================================

def generate_sql_queries_llm(rule: Dict[str, Any], table_columns: Dict[str, List[str]], 
                             all_schemas: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Generate SQL queries for each identified table using LLM.
    Multiple SQL queries may be generated for a single rule.
    
    Args:
        rule: Rule dictionary
        table_columns: Dictionary mapping table names to columns
        all_schemas: All table schemas
        
    Returns:
        List of SQL query dictionaries with table_name, sql_query, columns
    """
    print(f"\n[Task 3-4] Generating SQL queries using LLM for rule {rule.get('rule_id')}...", flush=True)
    
    if not table_columns:
        print("  ⚠️ No tables identified, skipping SQL generation")
        return []
    
    sql_queries = []
    
    # Prepare rule details
    rule_details = {
        'rule_id': rule.get('rule_id', ''),
        'rule_name': rule.get('rule_name', ''),
        'description': rule.get('description', ''),
        'rule_type': rule.get('rule_type', ''),
        'severity': rule.get('severity', ''),
        'domain_name': rule.get('domain_name', '')
    }
    
    # Generate SQL for each table
    for table_name, columns in table_columns.items():
        if table_name not in all_schemas:
            continue
        
        schema_info = all_schemas[table_name]
        columns_str = ', '.join(columns) if columns else 'all relevant columns'
        
        prompt = f"""You are a SQL expert. Generate a SQL query to validate a data quality rule against a specific table.

Rule Details:
{json.dumps(rule_details, indent=2)}

Target Table: {table_name}
Target Columns: {columns_str}

Table Schema:
- Table: {table_name}
- Columns: {json.dumps(schema_info['columns'], indent=2)}
- Record Count: {schema_info['record_count']}
- Foreign Keys: {json.dumps(schema_info['foreign_keys'], indent=2)}

Generate a SQL query that:
1. Identifies records in '{table_name}' that VIOLATE this rule
2. Returns the primary key(s) and relevant columns of violating records
3. Uses SQLite syntax (this is a SQLite database)
4. Handles NULL values correctly
5. Is optimized for performance

SQLite-specific notes:
- Use date('now') for current date
- Use strftime('%Y-%m-%d', column) for date formatting
- Use LIKE or GLOB for pattern matching (not REGEXP)
- Use CAST() for type conversions
- Use LENGTH() for string length

The query should return ONLY records that violate the rule. Return ONLY the SQL query, no explanations, no code blocks.
"""
        
        try:
            response = llm.invoke(prompt)
            sql = response.content.strip()
            
            # Clean up SQL
            sql = re.sub(r'^```(?:sql)?\s*|\s*```$', '', sql, flags=re.IGNORECASE | re.MULTILINE)
            sql = re.sub(r'^["\']|["\']$', '', sql)
            sql = sql.strip()
            
            if sql:
                sql_queries.append({
                    'table_name': table_name,
                    'sql_query': sql,
                    'columns': columns,
                    'domain': rule.get('domain_name', '')
                })
                print(f"  ✓ Generated SQL for {table_name}")
            else:
                print(f"  ⚠️ Empty SQL generated for {table_name}")
                
        except Exception as e:
            print(f"  ❌ Error generating SQL for {table_name}: {str(e)}")
            continue
    
    print(f"  ✓ Generated {len(sql_queries)} SQL query/queries total")
    return sql_queries

# ============================================================================
# TASK 5: Execute SQL and validate results using LLM
# ============================================================================

def execute_sql_query(conn: sqlite3.Connection, sql_query: str) -> tuple[List[Dict[str, Any]], Optional[str], float]:
    """
    Execute a SQL query and return results.
    
    Returns:
        Tuple of (results, error_message, execution_time)
    """
    if not sql_query:
        return [], "Empty SQL query", 0.0
    
    start_time = time.time()
    try:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute(sql_query)
        
        if cursor.description:
            columns = [desc[0] for desc in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            execution_time = time.time() - start_time
            return results, None, execution_time
        else:
            execution_time = time.time() - start_time
            return [], None, execution_time
            
    except Exception as e:
        execution_time = time.time() - start_time
        return [], str(e), execution_time

def validate_results_llm(rule: Dict[str, Any], sql_query: str, query_results: List[Dict[str, Any]], 
                        table_name: str, execution_time: float) -> Dict[str, Any]:
    """
    Use LLM to validate query results against the rule and identify violations.
    
    Args:
        rule: Rule dictionary
        sql_query: The SQL query that was executed
        query_results: Results from the SQL query
        table_name: Table that was queried
        execution_time: Query execution time
        
    Returns:
        Dictionary with validation results
    """
    print(f"\n[Task 5] Validating results using LLM for {table_name}...", flush=True)
    
    # Prepare rule information
    rule_info = {
        'rule_id': rule.get('rule_id', ''),
        'rule_name': rule.get('rule_name', ''),
        'description': rule.get('description', ''),
        'rule_type': rule.get('rule_type', ''),
        'severity': rule.get('severity', ''),
        'domain_name': rule.get('domain_name', '')
    }
    
    # Limit results for LLM processing (first 50 records)
    sample_results = query_results[:50]
    total_records = len(query_results)
    
    prompt = f"""You are a data quality analyst. Analyze the SQL query results against the data quality rule to identify violations.

Rule Information:
{json.dumps(rule_info, indent=2)}

SQL Query Executed:
{sql_query}

Query Results (showing {len(sample_results)} of {total_records} records):
{json.dumps(sample_results, indent=2, default=str)}

Total Records Returned: {total_records}

Analyze these results and determine:
1. Do these records represent violations of the rule?
2. What specific violations are present?
3. Which columns have violations?
4. What is the nature of each violation?

Return a JSON object with this structure:
{{
    "is_violation": true/false,
    "violation_count": number,
    "total_records_validated": number (estimate based on table size),
    "violations": [
        {{
            "record_key": "primary key or identifier",
            "violated_columns": ["column1", "column2"],
            "violation_type": "description of violation",
            "violation_details": "specific details about the violation"
        }}
    ],
    "violated_tables": ["table_name"],
    "violated_columns": ["column1", "column2"],
    "summary": "brief summary of violations found"
}}

Return ONLY the JSON object, no additional text.
"""
    
    try:
        response = llm.invoke(prompt)
        content = response.content.strip()
        
        # Extract JSON
        json_match = re.search(r'\{.*\}', content, re.DOTALL)
        if json_match:
            content = json_match.group(0)
        
        validation_result = json.loads(content)
        
        # Add metadata
        validation_result['rule_id'] = rule_info['rule_id']
        validation_result['rule_name'] = rule_info['rule_name']
        validation_result['domain'] = rule_info['domain_name']
        validation_result['table_name'] = table_name
        validation_result['sql_query'] = sql_query
        validation_result['execution_time_seconds'] = execution_time
        validation_result['timestamp'] = datetime.now().isoformat()
        
        # If we have more results than shown, update violation count
        if total_records > len(sample_results):
            validation_result['violation_count'] = total_records
            # Add all results as violations
            all_violations = []
            for i, result in enumerate(query_results):
                all_violations.append({
                    'record_index': i + 1,
                    'record_data': result,
                    'violated_columns': list(result.keys())
                })
            validation_result['violations'] = all_violations[:100]  # Limit to 100 for JSON size
        
        print(f"  ✓ Validation complete: {validation_result.get('violation_count', 0)} violation(s)")
        return validation_result
        
    except Exception as e:
        print(f"  ❌ Error validating results: {str(e)}")
        # Fallback result
        return {
            'rule_id': rule_info['rule_id'],
            'rule_name': rule_info['rule_name'],
            'domain': rule_info['domain_name'],
            'table_name': table_name,
            'sql_query': sql_query,
            'is_violation': len(query_results) > 0,
            'violation_count': len(query_results),
            'total_records_validated': 0,
            'violations': [{'record_data': r} for r in query_results[:10]],
            'violated_tables': [table_name],
            'violated_columns': [],
            'summary': f"Found {len(query_results)} records (validation error occurred)",
            'execution_time_seconds': execution_time,
            'timestamp': datetime.now().isoformat(),
            'error': str(e)
        }

# ============================================================================
# TASK 6: Report violations in JSON format
# ============================================================================

def generate_violation_report(all_validation_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Generate comprehensive violation report in JSON format.
    
    Args:
        all_validation_results: List of all validation results
        
    Returns:
        Comprehensive violation report dictionary
    """
    print(f"\n[Task 6] Generating violation report...")
    
    # Aggregate statistics
    total_rules = len(set(r.get('rule_id', '') for r in all_validation_results))
    total_violations = sum(r.get('violation_count', 0) for r in all_validation_results)
    total_queries = len(all_validation_results)
    
    # Group by rule
    rules_dict = {}
    for result in all_validation_results:
        rule_id = result.get('rule_id', 'unknown')
        if rule_id not in rules_dict:
            rules_dict[rule_id] = {
                'rule_id': rule_id,
                'rule_name': result.get('rule_name', ''),
                'domain': result.get('domain', ''),
                'sql_queries': [],
                'violations': [],
                'total_violations': 0,
                'tables_validated': set(),
                'columns_violated': set()
            }
        
        rules_dict[rule_id]['sql_queries'].append({
            'table_name': result.get('table_name', ''),
            'sql_query': result.get('sql_query', ''),
            'execution_time_seconds': result.get('execution_time_seconds', 0)
        })
        
        if result.get('is_violation', False):
            rules_dict[rule_id]['violations'].append(result)
            rules_dict[rule_id]['total_violations'] += result.get('violation_count', 0)
            rules_dict[rule_id]['tables_validated'].add(result.get('table_name', ''))
            rules_dict[rule_id]['columns_violated'].update(result.get('violated_columns', []))
    
    # Convert sets to lists for JSON serialization
    for rule_data in rules_dict.values():
        rule_data['tables_validated'] = list(rule_data['tables_validated'])
        rule_data['columns_violated'] = list(rule_data['columns_violated'])
    
    report = {
        'timestamp': datetime.now().isoformat(),
        'summary': {
            'total_rules_validated': total_rules,
            'total_sql_queries_executed': total_queries,
            'total_violations_found': total_violations,
            'rules_with_violations': sum(1 for r in rules_dict.values() if r['total_violations'] > 0)
        },
        'rules': list(rules_dict.values())
    }
    
    print(f"  ✓ Report generated:")
    print(f"    - {total_rules} rule(s) validated")
    print(f"    - {total_queries} SQL query/queries executed")
    print(f"    - {total_violations} total violation(s) found")
    
    return report

def save_violation_report(report: Dict[str, Any], output_file: str = None) -> str:
    """Save violation report to JSON file."""
    if not output_file:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"dq_violation_report_{timestamp}.json"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False, default=str)
    
    return os.path.abspath(output_file)

# ============================================================================
# Main Execution
# ============================================================================

def main():
    """Main execution function."""
    import sys
    import io
    
    # Configure console encoding for Windows
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    
    # Force output to be unbuffered
    sys.stdout.reconfigure(line_buffering=True) if hasattr(sys.stdout, 'reconfigure') else None
    
    print("=" * 80, flush=True)
    print("Data Quality Rule Validator", flush=True)
    print("=" * 80, flush=True)
    print("Starting validation process...", flush=True)
    
    # Check for API key
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        print("\n❌ Error: GEMINI_API_KEY not found in environment variables!", flush=True)
        print("Please set GEMINI_API_KEY in your .env file or environment.", flush=True)
        return
    
    print(f"✓ Gemini API key found (length: {len(api_key)})", flush=True)
    
    # Test LLM connection
    print("\nTesting LLM connection...", flush=True)
    try:
        test_response = llm.invoke("Say 'OK' if you can read this.")
        print(f"✓ LLM connection successful: {test_response.content[:50]}...", flush=True)
    except Exception as e:
        print(f"❌ LLM connection failed: {str(e)}", flush=True)
        print("Please check your GEMINI_API_KEY and network connection.", flush=True)
        return
    
    # Configuration
    rules_db_path = "./DataQualityRules.db"
    target_db_path = "./uk_health_insurance.db"
    
    print(f"\nChecking database files...", flush=True)
    print(f"  Rules DB: {os.path.abspath(rules_db_path)}", flush=True)
    print(f"  Target DB: {os.path.abspath(target_db_path)}", flush=True)
    
    # Validate database paths
    if not os.path.exists(rules_db_path):
        print(f"\n❌ Error: Rules database not found at {os.path.abspath(rules_db_path)}", flush=True)
        return
    
    if not os.path.exists(target_db_path):
        print(f"\n❌ Error: Target database not found at {os.path.abspath(target_db_path)}", flush=True)
        return
    
    print("✓ Both database files found", flush=True)
    
    try:
        # Connect to target database
        print("\nConnecting to target database...", flush=True)
        target_conn = sqlite3.connect(target_db_path)
        print(f"✓ Connected to target database: {os.path.abspath(target_db_path)}", flush=True)
        
        # Get all table schemas
        print("\nLoading target database schemas...", flush=True)
        all_schemas = get_all_table_schemas(target_conn)
        print(f"✓ Loaded schemas for {len(all_schemas)} table(s)", flush=True)
        
        # TASK 1: Fetch active rules
        print("\nFetching active rules from rules database...", flush=True)
        rules = fetch_active_rules(rules_db_path)
        if not rules:
            print("\n⚠️ No active rules found. Exiting.", flush=True)
            target_conn.close()
            return
        
        print(f"\n✓ Found {len(rules)} active rule(s) to process", flush=True)
        
        # Process each rule
        all_validation_results = []
        
        print(f"\n{'='*80}", flush=True)
        print(f"Starting rule processing...", flush=True)
        print(f"{'='*80}", flush=True)
        
        for rule_idx, rule in enumerate(rules, 1):
            print(f"\n{'='*80}", flush=True)
            print(f"Processing Rule {rule_idx}/{len(rules)}: {rule.get('rule_id')} - {rule.get('rule_name', 'N/A')}", flush=True)
            print(f"{'='*80}", flush=True)
            
            try:
                # TASK 2: Identify tables and columns using LLM
                table_columns = identify_tables_columns_llm(rule, all_schemas)
                
                if not table_columns:
                    print(f"  ⚠️ No tables identified for rule {rule.get('rule_id')}, skipping...")
                    continue
                
                # TASK 3-4: Generate SQL queries
                sql_queries = generate_sql_queries_llm(rule, table_columns, all_schemas)
                
                if not sql_queries:
                    print(f"  ⚠️ No SQL queries generated for rule {rule.get('rule_id')}, skipping...")
                    continue
                
                # Execute each SQL query and validate results
                for sq in sql_queries:
                    print(f"\n  Executing SQL for table: {sq['table_name']}")
                    
                    # Execute SQL
                    query_results, error, exec_time = execute_sql_query(target_conn, sq['sql_query'])
                    
                    if error:
                        print(f"    ❌ SQL Error: {error}")
                        all_validation_results.append({
                            'rule_id': rule.get('rule_id', ''),
                            'rule_name': rule.get('rule_name', ''),
                            'domain': rule.get('domain_name', ''),
                            'table_name': sq['table_name'],
                            'sql_query': sq['sql_query'],
                            'is_violation': False,
                            'violation_count': 0,
                            'error': error,
                            'execution_time_seconds': exec_time,
                            'timestamp': datetime.now().isoformat()
                        })
                    else:
                        print(f"    ✓ Query executed in {exec_time:.3f}s, returned {len(query_results)} record(s)")
                        
                        # TASK 5: Validate results using LLM
                        validation_result = validate_results_llm(
                            rule, sq['sql_query'], query_results, 
                            sq['table_name'], exec_time
                        )
                        all_validation_results.append(validation_result)
                
            except Exception as e:
                print(f"  ❌ Error processing rule: {str(e)}")
                import traceback
                traceback.print_exc()
                continue
        
        # TASK 6: Generate and save violation report
        if all_validation_results:
            report = generate_violation_report(all_validation_results)
            output_path = save_violation_report(report)
            
            print(f"\n{'='*80}")
            print("Validation Complete!")
            print(f"{'='*80}")
            print(f"\n✓ Violation report saved to: {output_path}")
            print(f"\nSummary:")
            print(f"  - Rules validated: {report['summary']['total_rules_validated']}")
            print(f"  - SQL queries executed: {report['summary']['total_sql_queries_executed']}")
            print(f"  - Total violations: {report['summary']['total_violations_found']}")
            print(f"  - Rules with violations: {report['summary']['rules_with_violations']}")
        else:
            print("\n⚠️ No validation results generated.")
        
    except Exception as e:
        print(f"\n❌ Fatal error: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        if 'target_conn' in locals():
            target_conn.close()
            print("\n✓ Database connection closed")

if __name__ == "__main__":
    main()

