# talk2data
You can talk to a SQL database containing a Insurance company's data like Customer, Policy, Quote, Sales, Commissions, Claims, Address, Agent
