# -*- coding: utf-8 -*-
"""
Created on Sat Nov 16 20:08:52 2024

@author: ravivarman.balaiyan
"""
#from langchain.chains import LLMChain

from langchain_community.utilities.sql_database import SQLDatabase
from dotenv import load_dotenv
import os
import time
import httpx
from langchain_openai import ChatOpenAI
#from langchain_core.prompts import PromptTemplate
#from langchain_core.output_parsers import StrOutputParser

load_dotenv()

# Initialize HTTP client with SSL verification disabled
client = httpx.Client(verify=False)

# Initialize the LLM with the provided configuration
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key=os.getenv("OPENAI_API_KEY"),  # Make sure to set this in your .env file
    http_client=client
)

def initialize_db_connection():
    # Connect to the SQL database
    db = SQLDatabase.from_uri("sqlite:///./data/uk_health_insurance.db")
    
    return db

def get_schema_db(db):
    # Schema of the db
    schema = db.get_table_info()
    return schema

def build_few_shots_prompt(db, chat_history=None):
    # Get schema
    db_schema = get_schema_db(db)

    few_shots = [
        {
            "input": "How many customers do we have?",
            "query": "SELECT COUNT(*) FROM customers;"
        },
        {
            "input": "List the top 10 claims by amount claimed",
            "query": "SELECT claim_number, amount_claimed FROM claims ORDER BY amount_claimed DESC LIMIT 10;"
        },
        {
            "input": "Show me the most common policy types",
            "query": "SELECT pt.name, COUNT(p.policy_id) as policy_count FROM policies p JOIN policy_types pt ON p.type_id = pt.type_id GROUP BY p.type_id ORDER BY policy_count DESC;"
        },
        {
            "input": "Which agent has the most active policies?",
            "query": "SELECT a.first_name, a.last_name, COUNT(p.policy_id) as active_policies FROM agents a JOIN policies p ON a.agent_id = p.agent_id WHERE p.status = 'active' GROUP BY a.agent_id ORDER BY active_policies DESC LIMIT 1;"
        },
        {
            "input": "List customers with claims in the last 30 days",
            "query": "SELECT DISTINCT c.first_name, c.last_name, cl.claim_date, cl.amount_claimed FROM customers c JOIN claims cl ON c.customer_id = cl.customer_id WHERE date(cl.claim_date) >= date('now', '-30 days') ORDER BY cl.claim_date DESC;"
        },
        {
            "input": "Show claims from the last year",
            "query": "SELECT * FROM claims WHERE date(claim_date) >= date('now', '-1 year');"
        },
        {
            "input": "What is the average claim amount by policy type?",
            "query": "SELECT pt.name, AVG(cl.amount_claimed) as avg_claim_amount FROM claims cl JOIN policies p ON cl.policy_id = p.policy_id JOIN policy_types pt ON p.type_id = pt.type_id GROUP BY p.type_id;"
        }
    ]
    chat_history_section = ""
    if chat_history:
        chat_history_section = f"""
        Previous conversation:
        {chat_history}
        """
    prompt = [
    f"""
    You are a SQL expert and an intelligent assistant. Your task is to translate natural language requests into accurate and efficient SQL queries based on a given database schema. Follow the guidelines below for every request:
    The SQL database has multiple tables, and these are the schemas: {db_schema},{chat_history_section}
    1. **Understand the Request**:
        - Carefully analyze the natural language request to determine the exact data requirements.
        - Identify the necessary tables, columns, and operations (e.g., filtering, sorting, joins, aggregations).
        - If the request seems ambiguous, state the ambiguity clearly and provide suggestions to resolve it.

    2. **Database Schema Awareness**:
        - Use only the provided schema, including table names, column names, and their relationships (e.g., primary and foreign keys).
        - Adhere to the data types mentioned in the schema and avoid mismatches (e.g., strings vs. integers).

    3. **Generate Efficient SQL Queries**:
        - Prioritize performance by using SQL best practices, such as minimizing subqueries where JOINs suffice and using indexed columns effectively.
        - Write queries that avoid unnecessary complexity and optimize for readability.
        - If the question is about the schema, return a SQL query to fetch table names and column names of all tables.

    4. **Edge Case Handling**:
        - Anticipate potential edge cases, such as null values, empty results, or large datasets.
        - Provide explanations or suggestions to handle such cases, if applicable.

    5. **Return Executable SQL**:
        - Provide ONLY the SQL query that can be directly executed on the specified database.
        - Remove three single quotes (```) in the beginning or end of the SQL query.
        - Also remove the word 'sql' in the beginning of the SQL.
        - In the SQL response, ONLY give the SQL, don't respond with the question along with the SQL. I want ONLY SQL, NOTHING ELSE ALONG WITH THAT.
        - Give only ONE SQL QUERY, DO NOT GIVE MULTIPLE SQL QUERIES.

    You can order the results by a relevant column to return the most interesting examples in the database.
    Never query for all the columns from a specific table, only ask for the relevant columns given the question.
    Also, the SQL code should not have ``` in the beginning or end and no 'sql' word in the output.
    You SHOULD respond ONLY the SQL QUERY, DO NOT RESPOND ANY SPECIAL CHARACTERS BEFORE OR AFTER THE SQL QUERY.
    You MUST double-check your query before executing it. If you get an error while executing a query, rewrite the query and try again.
    
    Important: This is a SQLite database, so you must use SQLite syntax and functions.
    For date operations, use SQLite's date functions:
    - Use `date('now')` for current date
    - Use `date('now', '-7 days')` for date arithmetic
    - Use `strftime('%Y-%m', date_column)` for date formatting
    - Never use MySQL-specific functions like DATE_SUB, DATE_ADD, or CURRENT_DATE()

    When writing queries:
    1. Use SQLite's date functions as shown above
    2. Always wrap date columns with the date() function when doing comparisons
    3. Use the format 'YYYY-MM-DD' for date literals

    DO NOT make any DML statements (INSERT, UPDATE, DELETE, DROP etc.) to the database.

    If the question does not seem related to the database, just return "I don't know" as the answer.
    If you get any error while running SQL query in the database, please answer politely as I can't fetch an answer due to a technical error.

    Here are some examples of user inputs and their corresponding SQL queries:
    """
]

    # Append each example to the prompt
    for sql_example in few_shots:
        prompt.append(
            f"\nExample - {sql_example['input']}, the SQL command will be something like this {sql_example['query']}")

    # Join prompt sections into a single string
    formatted_prompt = [''.join(prompt)]
    
    return formatted_prompt
    
def generate_sql_query(prompt, user_question):
    # Generate SQL query using the configured LLM
    response = llm.invoke(prompt[0] + user_question)
    return response.content

def run_query(db, sql_query):
    # Run sql query
    return db.run(sql_query)

# def get_gemini_llm():
#     # LLM
#     llm = model
#     #llm = genai.GenerativeModel(model_name="gemini-1.5-flash")
#     return llm
def second_llm_call(sql_response, user_question):
    prompt = f"""Based on the sql response, write an answer relating to the user question:
{user_question}

Don't show any error messages. If the SQL response is empty, please respond with a polite user-friendly message.

SQL response:
{sql_response}"""
    
    # Generate response using the configured LLM
    response = llm.invoke(prompt)
    return response.content

    
import streamlit as st

def main():
    # Configure settings of the page
    st.set_page_config(
        page_title="AIWA Chat with SQL Databases",
        page_icon="🧊",
        layout="wide")

    # Add a header
    st.header("AIWA - Conversational Insights - Talk 2 data")

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    for message in st.session_state.chat_history:
            with st.chat_message(message["role"]):
                st.write(message["content"])
    # Widget to provide questions
    user_question = st.chat_input("Ask me a question about Insurance database that contains Policy, Customer, Agent, Quote, Sales, Claims, Address etc",key="user_input")

    if user_question is not None:
        with st.chat_message("user"):
            st.write(user_question)

        with st.spinner("Fetching..."):
            st.session_state.chat_history.append({"role": "user", "content": user_question})
            # DB connection
            db = initialize_db_connection()


            chat_history = "\n".join([f"{m['role']}: {m['content']}" for m in st.session_state.chat_history])
            # Generate few shots prompt
            few_shots_prompt = build_few_shots_prompt(db, chat_history)

            # Generate SQL query
            sql_query = generate_sql_query(prompt=few_shots_prompt, user_question = user_question)

            # Execute SQL query
            sql_query = sql_query.strip()
            if sql_query != "I don't know":
                query_results = run_query(db = db, sql_query = sql_query)
                if query_results is None:
                    query_results = "No result found in database"                    
            else:
                query_results = "No result found in database"
                
            # LLM
            #llm = get_gemini_llm()

            # Final answer
            answer = second_llm_call(query_results, user_question)


            with st.chat_message("assistant"):
                response_placeholder = st.empty()
                full_response = ""
                for chunk in answer.split():
                    full_response += chunk + " "
                    time.sleep(0.05)
                    response_placeholder.markdown(full_response + "▌")
                response_placeholder.markdown(full_response)
                st.write(sql_query)

            
            st.session_state.chat_history.append({"role": "assistant", "content": answer})
            
            #st.write(sql_query)
            #st.write(query_results)
            #st.success("Done")

if __name__ == "__main__":
    main()
